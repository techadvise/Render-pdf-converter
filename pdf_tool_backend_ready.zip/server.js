const express = require("express");
const fileUpload = require("express-fileupload");
const pdfRoutes = require("./routes/pdf");
const path = require("path");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());
app.use(fileUpload());
app.use("/api/pdf", pdfRoutes);
app.use(express.static(path.join(__dirname, 'frontend')));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
